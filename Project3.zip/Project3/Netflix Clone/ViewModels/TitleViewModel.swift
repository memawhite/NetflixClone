

import Foundation


struct TitleViewModel {
    let titleName: String
    let posterURL: String
}
