//
//  DownloadManager.swift
//  Netflix Clone
//
//  Created by Amr Hossam on 19/01/2022.
//

import Foundation
import CoreData




class DownloadManager {
    static let shared = DownloadManager()
    
    func downloadItem(with model: Title) {
        
    }
}
